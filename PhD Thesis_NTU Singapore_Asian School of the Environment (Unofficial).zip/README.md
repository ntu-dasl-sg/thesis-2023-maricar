Unofficial template for a PhD dissertation at the Asian School of Environment, Nanyang Technological University Singapore.

I wrote and submitted my PhD dissertation using this structure in 2023. 

Please refer to NTU guidelines for PhD dissertation format:
https://www.ntu.edu.sg/research/theses-dissertations

This template is generated through major modifications of unofficial RMIT and Swinburne MS templates found in the Overleaf Gallery.

Your main chapters go in the 'Chapters' folder.
Your opening matter (e.g. abstract, declaration statements, acknowledgements) go into the 'Intro' folder.

The sequence recommended by NTU OAS is as follows:

i. Title Page
ii. Statement of Originality
iii. Supervisor Declaration Statement
iv. Authorship Attribution Statement
v. Acknowledgements
vi. Table of Contents
vii. Summary

Hope you find this useful.

-- Maricar Rabonza
maricar.rabonza@gmail.com


# Probably a useful link:
% https://tex.stackexchange.com/questions/19017/how-to-place-a-table-on-a-new-page-with-landscape-orientation-without-clearing-t



